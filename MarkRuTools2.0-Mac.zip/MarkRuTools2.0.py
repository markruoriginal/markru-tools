import os
import sys
import ctypes
import webbrowser

# Check for administrator rights
def has_admin_rights():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not has_admin_rights():
    print("Requesting administrator rights.")
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, " ".join(sys.argv), None, 1)
    sys.exit()

# Search functions
def search_google():
    query = input("Enter a query for Google Search: ")
    url = f'https://www.google.com/search?q={query}'
    webbrowser.open(url)

def search_bing():
    query = input("Enter a query for Bing Search: ")
    url = f'https://www.bing.com/search?q={query}'
    webbrowser.open(url)

def search_yandex():
    query = input("Enter a query for Yandex Search: ")
    url = f'https://yandex.ru/search/?text={query}'
    webbrowser.open(url)

# Calculator function
def calculator():
    print("Calculator. Enter an expression (e.g., 2 + 3 * 4):")
    expr = input(">>> ")
    try:
        result = eval(expr, {'__builtins__': None}, {})
        print(f"Result: {result}")
    except Exception as e:
        print(f"Calculation error: {e}")

# Main menu
def main_menu():
    while True:
        # Set window color and title (optional)
        try:
            os.system('color 1E')
        except:
            pass
        try:
            os.system('title MrMarkYT (TM)')
        except:
            pass

        print("\n===== MarkRu Tools + Games =====")
        print("1. Search Google.com")
        print("2. Search bing.com")
        print("3. Search yandex.ru")
        print("4. Calculator Mode")
        print("5. Launch Task Manager (Windows)")
        print("6. Clear TEMP folder")
        print("7. Reboot PC in 1 minute")
        print("8. Shut down PC in 1 minute")
        print("9. Cancel shutdown/reboot")
        print("10. Change window color")
        print("11. Reboot immediately")
        print("12. Shutdown immediately")
        print("13. Play: Guess the number")
        print("14. Play: Motorcycle race")
        print("15. Play: Tic-tac-toe")
        print("16. Create a file")
        print("17. Delete a file")
        print("0. Exit")

        choice = input("Select an option: ")

        if choice == '1':
            search_google()
        elif choice == '2':
            search_bing()
        elif choice == '3':
            search_yandex()
        elif choice == '4':
            calculator()
        elif choice == '5':
            os.system("taskmgr")
        elif choice == '6':
            os.system("del %TEMP%\\* /Q /F")
            print("TEMP folder cleared.")
        elif choice == '7':
            os.system("shutdown /r /t 60")
            print("Reboot in 1 minute initiated.")
        elif choice == '8':
            os.system("shutdown /s /t 60")
            print("Shutdown in 1 minute initiated.")
        elif choice == '9':
            os.system("shutdown /a")
            print("Shutdown/reboot canceled.")
        elif choice == '10':
            change_window_color()
        elif choice == '11':
            os.system("shutdown /r /f /t 0")
        elif choice == '12':
            os.system("shutdown /s /f /t 0")
        elif choice == '13':
            play_guess_number()
        elif choice == '14':
            motorcycle_race()
        elif choice == '15':
            tic_tac_toe()
        elif choice == '16':
            create_file()
        elif choice == '17':
            delete_file()
        elif choice == '0':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

# Implementation of games and additional functions (examples)
import random

def play_guess_number():
    number = random.randint(1, 50)
    print("I've picked a number from 1 to 50. Try to guess it!")
    while True:
        try:
            guess = int(input("Your answer: "))
            if guess == number:
                print("Congratulations! You guessed it!")
                break
            elif guess < number:
                print("Lower.")
            else:
                print("Higher.")
        except:
            print("Please enter a number.")

def motorcycle_race():
    print("Error -1291 Additional package for the game is not loaded! ")
    # Optional game implementation can be added here

def tic_tac_toe():
    print("Playing: Tic-tac-toe:")
    board = [' ']*9

    def print_board():
        print(f"{board[0]}|{board[1]}|{board[2]}")
        print("-+-+-")
        print(f"{board[3]}|{board[4]}|{board[5]}")
        print("-+-+-")
        print(f"{board[6]}|{board[7]}|{board[8]}")

    def check_win(player):
        wins = [(0,1,2), (3,4,5), (6,7,8),
                (0,3,6), (1,4,7), (2,5,8),
                (0,4,8), (2,4,6)]
        return any(all(board[i] == player for i in combo) for combo in wins)

    current_player = 'X'
    for _ in range(9):
        print_board()
        move = input(f"Player {current_player}, your move (0-8): ")
        try:
            move = int(move)
            if board[move] == ' ':
                board[move] = current_player
                if check_win(current_player):
                    print_board()
                    print(f"Player {current_player} wins!")
                    return
                current_player = 'O' if current_player=='X' else 'X'
            else:
                print("This field is already occupied.")
        except:
            print("Invalid input.")
    print_board()
    print("It's a draw!")

# Functions for file operations
def create_file():
    dir_path = input("Enter directory path to create the file in: ")
    filename = input("Enter filename (e.g., myfile.txt): ")
    full_path = os.path.join(dir_path, filename)
    content = input("Enter file content: ")
    try:
        os.makedirs(dir_path, exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"File {full_path} successfully created.")
    except Exception as e:
        print(f"Error creating file: {e}")

def delete_file():
    dir_path = input("Enter directory path: ")
    filename = input("Enter filename to delete: ")
    full_path = os.path.join(dir_path, filename)
    try:
        if os.path.exists(full_path):
            os.remove(full_path)
            print(f"File {full_path} successfully deleted.")
        else:
            print("File not found.")
    except Exception as e:
        print(f"Error deleting file: {e}")

# Window color change menu
def change_window_color():
    print("Available colors:")
    print("1. Blue")
    print("2. Green")
    print("3. Red")
    print("4. White")
    choice = input("Choose a color (1-4): ")
    color_codes = {'1':'1E', '2':'2E', '3':'4E', '4':'0F'}
    if choice in color_codes:
        os.system(f'color {color_codes[choice]}')
    else:
        print("Invalid choice.")

def main():
    # Open welcome HTML
    webbrowser.open('file:///C:/MarkRuTools/welcome.html')
    main_menu()

if __name__ == "__main__":
    main()
